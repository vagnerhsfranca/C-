/*
 * util.h
 *
 *  Created on: 15 de dez de 2017
 *      Author: ramide
 */


void print(int * array, int ini, int end);

void print(int * array, int len);

